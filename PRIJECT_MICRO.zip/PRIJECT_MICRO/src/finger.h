#ifndef FINGER_H
#define FINGER_H


#include <Arduino.h>
#include <Adafruit_Fingerprint.h>

// กำหนดขา RX/TX ของ ESP32-S3
#define FINGERPRINT_RX_PIN 18
#define FINGERPRINT_TX_PIN 17

class FingerprintEnroll {
  public:
    FingerprintEnroll();
    void begin();              // เริ่มต้น Serial และตรวจสอบเซ็นเซอร์
    void enrollLoop();         // loop สำหรับ enroll
  private:
    HardwareSerial fingerSerial = HardwareSerial(2);
    Adafruit_Fingerprint finger = Adafruit_Fingerprint(&fingerSerial);
    uint8_t id;
    uint8_t readNumber();
    uint8_t getFingerprintEnroll();
    int checkFingerprint();
};

#endif
