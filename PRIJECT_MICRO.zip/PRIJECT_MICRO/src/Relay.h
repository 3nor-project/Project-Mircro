#ifndef RELAY_H
#define RELAY_H
#include <Arduino.h>
#define RELAY1 13

void setupRelay();
void set_relay(bool state);



#endif  