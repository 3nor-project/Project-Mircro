#include "checkfinger.h"
#include <Arduino.h>

FingerprintDetect::FingerprintDetect() {}

void FingerprintDetect::begin() {
  pinMode(lockPin, OUTPUT);
  digitalWrite(lockPin, LOW);

  Serial.begin(9600);
  Serial.println("\nFingerprint detection on ESP32-S3");

  fingerSerial.begin(57600, SERIAL_8N1, rxPin, txPin);
  finger.begin(57600);

  if(finger.verifyPassword()) {
    Serial.println("Found fingerprint sensor!");
  } else {
    Serial.println("Did not find fingerprint sensor :(");
    while(1) { delay(1); }
  }

  finger.getTemplateCount();
  Serial.print("Sensor contains "); Serial.print(finger.templateCount); Serial.println(" templates");
  Serial.println("Waiting for valid finger...");
}

int FingerprintDetect::getFingerprintIDez() {
  uint8_t p = finger.getImage();
  if(p != FINGERPRINT_OK) {
    if(p != FINGERPRINT_NOFINGER) {
      // แสดง error ถ้าต้องการ
    }
    return -1;
  }

  p = finger.image2Tz();
  if(p != FINGERPRINT_OK) return -1;

  p = finger.fingerFastSearch();
  if(p != FINGERPRINT_OK) return -1;

  Serial.print("Found ID #"); Serial.print(finger.fingerID);
  Serial.print(" with confidence "); Serial.println(finger.confidence);



  return finger.fingerID;
}

int FingerprintDetect::loopDetect() {
    uint8_t p = finger.getImage();
    if (p != FINGERPRINT_OK) return -2;   // ไม่มีนิ้ววาง

    p = finger.image2Tz();
    if (p != FINGERPRINT_OK) return -2;   // ไม่มีนิ้ว หรือภาพไม่ชัด

    p = finger.fingerFastSearch();
    if (p != FINGERPRINT_OK) {
        if(p == FINGERPRINT_NOTFOUND) {
            Serial.println("No match found");
            return -1;   // ✅ มีนิ้วแต่ไม่ตรง
        }
        return -2;       // กรณี error อื่น ๆ
    }

    Serial.print("Found ID #"); Serial.print(finger.fingerID);
    Serial.print(" with confidence "); Serial.println(finger.confidence);

    return (int)finger.fingerID;  // ✅ คืนค่าเป็น ID
}
