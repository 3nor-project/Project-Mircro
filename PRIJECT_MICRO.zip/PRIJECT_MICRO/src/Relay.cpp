#include <Arduino.h>
#include "Relay.h"


void setupRelay() {
  pinMode(RELAY1, OUTPUT);
}

void set_relay(bool state) {
     digitalWrite(RELAY1, state ? 1 : 0);
}

