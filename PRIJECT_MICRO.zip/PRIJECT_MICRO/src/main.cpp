#include <Arduino.h>
#include <Keypad.h>
#include "Relay.h"
#include "MP3.h"
#include "checkfinger.h"

const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte rowPins[ROWS] = {7,6,46,4};          
byte colPins[COLS] = {3,8,9,15};      

char password[5]; // ต้อง +1 สำหรับ '\0'
int i = 0;

Keypad kpd = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);
FingerprintDetect fpDetect;

void setup() {
  Serial.begin(9600);
  Serial.println("กรุณาใส่รหัสผ่าน 4 หลัก:");
  setupRelay();
  MP3_setup();
  fpDetect.begin(); 
}

void loop() {
  char key = kpd.getKey();

  // อ่านนิ้วมือทุก loop
  int id = fpDetect.loopDetect();

  if(id >= 0) {           // เจอนิ้วที่ match
    Serial.print("Detected Finger ID: "); Serial.println(id);
    if(id == 0) {           // นิ้วถูก
      Serial.println("ผ่าน");
      MP3_play(1);
      set_relay(true);
      delay(5000);
      set_relay(false);
    } else {                // เจอนิ้ว แต่ไม่ใช่ ID ที่อนุญาต
      Serial.println("ลองใหม่อีกครั้ง");
      MP3_play(2);
      set_relay(false);
    }
  } 
  else if(id == -1) {       // มีนิ้วแต่ไม่ match
    Serial.println("ลองใหม่อีกครั้ง");
    MP3_play(2);
    set_relay(false);
  }
  // id == -2 → ไม่มีนิ้ว → ไม่ทำอะไร

  // ตรวจสอบ password
  if(key) {
    Serial.print(key);
    password[i++] = key;

    if(i == 4) {
      password[4] = '\0';
      Serial.println();

      if(strcmp(password, "1234") == 0) {
        Serial.println("Access Granted (Password)!");
        MP3_play(1);
        set_relay(true);
        delay(5000);
        set_relay(false);
      } else {
        Serial.println("Access Denied (Password)!");
        MP3_play(2);
        set_relay(false);
      }

      i = 0; // รีเซ็ตรหัสใหม่
    }
  }

  delay(50);
}
