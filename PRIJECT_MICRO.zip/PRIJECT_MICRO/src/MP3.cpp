#include "MP3.h"

HardwareSerial mySerial(1);      
DFRobotDFPlayerMini myDFPlayer;   

int volumeLevel = 15;

void MP3_setup() {
  mySerial.begin(9600, SERIAL_8N1, 1, 2);

  if (!myDFPlayer.begin(mySerial)) {
    Serial.println(F("DFPlayer init failed!"));
    while (true) { delay(0); }
  }

  myDFPlayer.volume(volumeLevel);
  Serial.println(F("DFPlayer ready!"));
}

void MP3_play(int track) {
  myDFPlayer.play(track);
}
