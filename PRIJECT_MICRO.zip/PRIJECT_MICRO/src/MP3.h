#ifndef MP3_H
#define MP3_H
#include <Arduino.h>
#include <DFRobotDFPlayerMini.h>

void MP3_setup();
void MP3_play(int track);
#endif
