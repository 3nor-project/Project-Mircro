#ifndef CHECKFINGER_H
#define CHECKFINGER_H

#include <Arduino.h>
#include <Adafruit_Fingerprint.h>

class FingerprintDetect {
  public:
    FingerprintDetect();          // constructor
    void begin();                 // เริ่มเซ็นเซอร์
    int loopDetect();             // อ่านลายนิ้วมือ และคืนค่า ID
  private:
    HardwareSerial fingerSerial = HardwareSerial(2);
    Adafruit_Fingerprint finger = Adafruit_Fingerprint(&fingerSerial);
    const uint8_t rxPin = 17;
    const uint8_t txPin = 18;
    const uint8_t lockPin = 4;
    int getFingerprintIDez();     // internal function
};


#endif
